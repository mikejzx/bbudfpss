
/*
	bbudfpss (Basic Backup Utility Designed for Proprietary Software-running Systems)
	- An extremely minimal tool for creating a compressed backup of a folder,
		and pushing it to an arbitrary folder. 
	- The resulting file will be given a proper timestamped name, and 
		compressed into a tarball or (in future) another archive format.
*/
/*
	main.cpp
	Entry point of the CLI application.
	The GUI application will be a front-end for this.
*/

// Include pre-compiled header.
#include "pch.h"
#include "archiver.h"

// Function prototypes.
void get_dir_files(std::vector<std::string>&, const std::string&, bool);

int main(int argc, char* argv[])
{
	std::cout << "bbudfpss v0.1" << std::endl;
	
	// Need at least two arguments.
	if (argc < 2)
	{
		std::cerr << "Missing parameters. Usage: bbudfpss <input directory> <output directory>" << std::endl;
		std::cin.get();
		return -1;
	}

	// Get absolute paths
	char inputDir[4096], outputDir[4096];
	if (!GetFullPathNameA(argv[1], 4096, inputDir, NULL))
	{
		std::cerr << "Invalid input file path" << std::endl;
	}
	if (!GetFullPathNameA(argv[2], 4096, outputDir, NULL))
	{
		std::cerr << "Invalid output file path" << std::endl;
	}

	// Make sure input is a directory.
	DWORD result = GetFileAttributesA(inputDir);
	if ((result & FILE_ATTRIBUTE_DIRECTORY) == 0)
	{
		std::cerr << "Input must be a directory." << std::endl;
		return -1;
	}
	if (result == INVALID_FILE_ATTRIBUTES)
	{
		std::cerr << "Invalid directory. Make sure it exists." << std::endl;
		return -1;
	}

	// Get all the files in the input directory,
	std::vector<std::string> v;
	get_dir_files(v, inputDir, true);
	
	// Get a timestamp string in format:
	// DDMMYY_HH-MM-SS
	char datestamp[6];
	char timestamp[6];
	SYSTEMTIME systime;
	GetLocalTime(&systime);
	GetDateFormatA(LOCALE_USER_DEFAULT, NULL, &systime, "ddMMyy", datestamp, 6);
	GetTimeFormatA(LOCALE_USER_DEFAULT, NULL, &systime, "'_'HH'-'mm", timestamp, 7);

	// Write to archive.
	char outname[MAX_PATH];
	strcpy_s(outname, outputDir);
	strcat_s(outname, "\\Backup_");
	strcat_s(outname, datestamp);
	strcat_s(outname, timestamp);
	strcat_s(outname, ".tar");
	write_archive(outname, v, inputDir);

	//
	// Compress the archive.
	//

	// Create input stream from the archive
	std::ifstream infile(outname, std::ios_base::binary);
	infile.seekg(0, std::ios_base::end);
	size_t len = infile.tellg();
	infile.seekg(0, std::ios_base::beg);

	// Read bytes
	std::vector<char> buffer;
	buffer.reserve(len);
	std::copy(std::istreambuf_iterator<char>(infile),
		std::istreambuf_iterator<char>(),
		std::back_inserter(buffer));
	infile.close();

	// Replace uncompressed archive with the compressed one.
	std::remove(outname);
	strcat_s(outname, ".gz");

	const char* buff_uncomp = buffer.data();
	size_t buff_size_uncomp = buffer.size() * sizeof(char);

	zstr::ofstream outfile(outname);
	outfile.write(buff_uncomp, buff_size_uncomp);

	return 0;
}

// Get a vector of all files in a directory.
// Will not work with Unicode currently!
// https://stackoverflow.com/questions/306533/how-do-i-get-a-list-of-files-in-a-directory-in-c
void get_dir_files(std::vector<std::string>& out, const std::string& directory, bool ignore_hidden)
{
	HANDLE dir;
	WIN32_FIND_DATAA file_data;

	if ((dir = FindFirstFileA((directory + "\\*").c_str(), &file_data))
		== INVALID_HANDLE_VALUE)
	{
		// No files found.
		return;
	}

	do
	{
		const std::string filename = file_data.cFileName;
		const std::string full_filename = directory + "\\" + filename;
		const bool is_dir = (file_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;

		if (ignore_hidden && filename[0] == '.')
		{
			continue;
		}

		if (is_dir)
		{
			// Run it recursively into each directory too.
			// First we check that the directory isn't '.' or '..'
			size_t filename_len = filename.length();
			if (filename[0] == '.' && (filename_len == 1
				|| (filename_len == 2 && filename[1] == '.')))
			{
				continue;
			}

			get_dir_files(out, full_filename, ignore_hidden);
			continue;
		}

		// Push to vector.
		out.push_back(full_filename);
	} while (FindNextFileA(dir, &file_data));

	FindClose(dir);
}
