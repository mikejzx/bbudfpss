https://github.com/mateidavid/zstr
