#ifndef ARCHIVER_H
#define ARCHIVER_H

#include "archiver.h"

void write_archive(const char*, const std::vector<std::string>&, const char*);

#endif